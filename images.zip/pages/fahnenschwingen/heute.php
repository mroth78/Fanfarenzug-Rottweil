<h2>Fahnenschwingen heute</h2>

<p>Der Fähnrich war für seinen Kameraden Orientierungspunkt in der Schlacht und die Fahne war Symbol für Einheit und Stärke der Truppe. </p>
<p>Heute tritt das Militärische völlig in den Hintergrund und es überwiegt der sportliche und künstlerische Aspekt. <br>Ganze Choreographien kann man aus einzelnen Figuren zusammensetzen, deren Namen noch an die militärische Geschichte erinnern (Helmbusch, Harnisch, Schwert, Gürtel usw.) </p>
<p>Heute geht es nicht mehr um Leben und Tod sondern um ein faires Kräftemessen und sportliche Gemeinschaft wenn Fahnenschwinger im Wettkampf gegeneinander antreten.</p>
<p>Es werden Technik und Haltung, sowie künstlerischer Ausdruck bis hin zu Akrobatik in verschiedenen Disziplinen bewertet.</p>
<p>Schon die jüngsten Fahnenschwinger zeigen im "Einzel" ihr Können im Rahmen eines Pflichtprogramms. <br>Die Erwachsenen haben dagegen die Freiheit, vorgeschriebene Elemente in einer Kür darzubieten. </p>
<p>In Duetten oder Gruppenwettkämpfen wird nicht nur die ausgefeilte Technik sondern auch die Synchronität und die musikalische Interpretation zu eine Musikstück bewertet. </p>
<p>Innerhalb der Disziplinen gibt es dann auch noch Größenunterschiede bei den Fahnen.</p>
