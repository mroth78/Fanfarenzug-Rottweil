<h2>Plazierungen</h2>
<h3>Ute Thom (geb. Günthner)</h3>
<table>
        <tbody>
                <tr>
                        <td>9. Platz</td>
                        <td>Deutsche Meisterschaft 2002</td>
                </tr>
                <tr>
                        <td>5. Platz</td>
                        <td>Landesmeisterschaft 2003</td>
                </tr>
                <tr>
                        <td>19. Platz</td>
                        <td>Deutsche Meisterschaft 2004</td>
                </tr>
                <tr>
                        <td>4. Platz</td>
                        <td>
                                Weltmeisterschaft im Fahnenhochwurf 2004
                        </td>
                </tr>
                <tr>
                        <td>7. Platz</td>
                        <td>
                                Weltmeisterschaft im Fahnenhochwurf 2005
                        </td>
                </tr>
                <tr>
                        <td>6. Platz</td>
                        <td>Landesmeisterschaft 2005</td>
                </tr>
                <tr>
                        <td>6. Platz</td>
                        <td>
                                Weltmeisterschaft im Fahnenhochwurf 2006
                        </td>
                </tr>
                <tr>
                        <td>11. Platz</td>
                        <td>
                                Damen B1 Deutsche Meisterschaft 2006
                        </td>
                </tr>
                <tr>
                        <td>2. Platz</td>
                        <td>
                                Damen B1 Landesmeisterschaft 2007
                        </td>
                </tr>
                <tr>
                        <td>4. Platz</td>
                        <td>
                                Damen B1 Landesmeisterschaft 2007
                        </td>
                </tr>
                <tr>
                        <td>- Landesmeisterin -</td>
                        <td>Damen offene Klasse 2009</td>
                </tr>
                <tr>
                        <td>6. Platz</td>
                        <td>
                                Damen offene Klasse Deutsche Meisterschaft 2010
                        </td>
                </tr>
                <tr>
                        <td>8. Platz</td>
                        <td>
                                Damen offene Klasse Landesmeisterschaft 2011
                        </td>
                </tr>
                <tr>
                        <td>17. Platz</td>
                        <td>
                                Damen offene Klasse Deutsche Meisterschaft 2012
                        </td>
                </tr>
                <tr>
                        <td>5. Platz</td>
                        <td>
                                Damen offene Klasse Landesmeisterschaft 2013
                        </td>
                </tr>
                <tr>
                        <td>10. Platz</td>
                        <td>
                                Deutsche Meisterschaft 2017 (Bad Urach)
                        </td>
                </tr>
                <tr>
                        <td>13. Platz</td>
                        <td>
                                17. Weltmeisterschaft im Fahnenhochwerfen in Nusplingen (2018) Klasse Damen offene Klasse  (1979 – 2002) 6,000 m
                        </td>
                </tr>
                <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                </tr>
        </tbody>
</table>
<p>
        <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
</p>
<div>
        <header>
                <h3>Monika Günthner</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>- Deutsche Meisterin -</td>
                                <td>im Fahnenschwingen 2002</td>
                        </tr>
                        <tr>
                                <td>- Weltmeisterin -</td>
                                <td>
                                        im Fahnenhochwurf mit Weltrekord 6,10m 2003
                                </td>
                        </tr>
                        <tr>
                                <td>- Landesmeisterin -</td>
                                <td>im Fahnenschwingen 2003</td>
                        </tr>
                        <tr>
                                <td>22. Platz</td>
                                <td>Deutsche Meisterschaft 2004</td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2004
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2005
                                </td>
                        </tr>
                        <tr>
                                <td>12. Platz</td>
                                <td>Landesmeisterschaft 2005</td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2006
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Damen A1 Landesmeisterschaft 2007
                                </td>
                        </tr>
                        <tr>
                                <td>13. Platz</td>
                                <td>
                                        Damen B1 Landesmeisterschaft 2007
                                </td>
                        </tr>
                        <tr>
                                <td>14. Platz</td>
                                <td>
                                        Einzel Damen offene Klasse Landesmeisterschaft 2013
                                </td>
                        </tr>
                        <tr>
                                <td>8. Platz</td>
                                <td>
                                        1. offene Süddeutsche-Meisterschaft Baden-Württemberg im Fahnenhochwerfen / Bretten
                                        <br>
                                        Altersklasse Damen, offene Klasse  (6,50 m)
                                </td>
                        </tr>
                        <tr>
                                <td>13. Platz</td>
                                <td>
                                        Deutsche Meisterschaft 2017 (Bad Urach)
                                </td>
                        </tr>
                        <tr>
                                <td>11. Platz</td>
                                <td>
                                        17. Weltmeisterschaft im Fahnenhochwerfen in Nusplingen (2018) Klasse Damen offene Klasse  (1979 – 2002) 7,000 m
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3>Georg Abele</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>3. Platz</td>
                                <td>Deutsche Meisterschaft 2002</td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Herren A2 und B2  Landesmeisterschaft 2003
                                </td>
                        </tr>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        Herren B3 Deutsche Meisterschaft 2004
                                </td>
                        </tr>
                        <tr>
                                <td>18. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2004
                                </td>
                        </tr>
                        <tr>
                                <td>14. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2005
                                </td>
                        </tr>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        Herren A3 Landesmeisterschaft 2005
                                </td>
                        </tr>
                        <tr>
                                <td>- Landesmeister -</td>
                                <td>Herren B3 2005</td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Herren B3 Deutsche Meisterschaft 2006
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        Herren A3 Deutsche Meisterschaft 2006
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Herren A3 Landesmeisterschaft 2007
                                </td>
                        </tr>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        Herren B3 Landesmeisterschaft 2007
                                </td>
                        </tr>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        Herren/Damen B3 Deutsche Meisterschaft 2008
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Herren A3/A4 Deutsche Meisterschaft 2008
                                </td>
                        </tr>
                        <tr>
                                <td>11. Platz</td>
                                <td>
                                        Herren offene Klasse Landesmeisterschaft 2009
                                </td>
                        </tr>
                        <tr>
                                <td>15. Platz</td>
                                <td>
                                        Herren offene Klasse Deutsche Meisterschaft 2010
                                </td>
                        </tr>
                        <tr>
                                <td>7. Platz</td>
                                <td>
                                        Herren offene Klasse Landesmeisterschaft 2011
                                </td>
                        </tr>
                        <tr>
                                <td>5 . Platz</td>
                                <td>
                                        Herren offene Klasse Deutsche Meisterschaft 2012
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        Einzel Herren Altersklasse Landesmeisterschaft 2013
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3>Wolfgang Grundmann</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>
                                        Landesmeister im Fahnenschwingen 2001
                                </td>
                                <td>&nbsp;</td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3>Arthur Duttenhöfer</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>13. Platz</td>
                                <td>
                                        Jungen Landesmeisterschaft 2003
                                </td>
                        </tr>
                        <tr>
                                <td>10. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2004
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3>Julia Duttenhöfer</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>12. Platz</td>
                                <td>Landesmeisterschaft 2003</td>
                        </tr>
                        <tr>
                                <td>7. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2005
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2005
                                </td>
                        </tr>
                        <tr>
                                <td>6. Platz</td>
                                <td>
                                        Mädchen Landesmeisterschaft 2005
                                </td>
                        </tr>
                        <tr>
                                <td>12. Platz</td>
                                <td>
                                        Mädchen Deutsche Meisterschaft 2006
                                </td>
                        </tr>
                        <tr>
                                <td>5. Platz</td>
                                <td>
                                        Mädchen Landesmeisterschaft 2007
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        Mädchen Landesmeisterschaft 2009
                                </td>
                        </tr>
                        <tr>
                                <td>10. Platz</td>
                                <td>
                                        Damen offene Klasse Deutsche Meisterschaft 2010
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3>Peter Günthner</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Jungen Deutsche Meisterschaft 2000
                                </td>
                        </tr>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        Jungen Landesmeisterschaft 2001
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        Jungen Landesmeisterschaft 2002
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3>Klaus Günthner</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>4. Platz</td>
                                <td>Deutsche Meisterschaft 2000</td>
                        </tr>
                        <tr>
                                <td>2. Platz</td>
                                <td>Landesmeisterschaft 2001</td>
                        </tr>
                        <tr>
                                <td>5. Platz</td>
                                <td>Deutsche Meisterschaft 2002</td>
                        </tr>
                        <tr>
                                <td>2. Platz</td>
                                <td>Landesmeisterschaft 2003</td>
                        </tr>
                        <tr>
                                <td>12. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2004
                                </td>
                        </tr>
                        <tr>
                                <td>- Deutscher Meister -</td>
                                <td>Herren B3 2004</td>
                        </tr>
                        <tr>
                                <td>- Landesmeister -</td>
                                <td>Herren A4 2005</td>
                        </tr>
                        <tr>
                                <td>- Deutscher Meister  -</td>
                                <td>Herren B4  2006</td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Herren A4 Landesmeisterschaft 2007
                                </td>
                        </tr>
                        <tr>
                                <td>- Landesmeister -</td>
                                <td>Herren B4 2007</td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3 >Lorena Karbstein</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Pagen Landesmeisterschaft 2009
                                </td>
                        </tr>
                        <tr>
                                <td>5. Platz</td>
                                <td>
                                        Landesmeisterschaft im Fahnenhochwurf Mädchen AK 3 2010
                                </td>
                        </tr>
                        <tr>
                                <td>5. Platz</td>
                                <td>
                                        Mädchen Deutsche Meisterschaft 2010
                                </td>
                        </tr>
                        <tr>
                                <td>7. Platz</td>
                                <td>
                                        Landesmeisterschaft im Fahnenhochwurf Mädchen AK3 2011
                                </td>
                        </tr>
                        <tr>
                                <td>5. Platz</td>
                                <td>
                                        Mädchen Landesmeisterschaft 2011
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Landesmeisterschaft im Fahnenhochwurf Mädchen AK4 2012
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        Mädchen Deutsche Meisterschaft 2012
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf Mädchen AK4 2012
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        Einzel Mädchen Landesmeisterschaft 2013
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        1. offene Süddeutsche-Meisterschaft Baden-Württemberg im Fahnenhochwerfen / Bretten
                                        <br>
                                        Altersklasse Damen (7,50 m)
                                </td>
                        </tr>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2016 (Bad Mergentheim) Altersklasse Damen (8,00 m)
                                </td>
                        </tr>
                        <tr>
                                <td>7. Platz</td>
                                <td>
                                        17. Weltmeisterschaft im Fahnenhochwerfen in Nusplingen (2018) Klasse Damen offene Klasse  (1979 – 2002) 7,500 m
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        18. Weltmeisterschaft im Fahnenhochwerfen in Eschweiler (2019) Klasse Damen offene Klasse  (1980 – 2003) 7,500 m
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3  >Melissa Karbstein</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>5. Platz</td>
                                <td>
                                        Mädchen Landesmeisterschaft 2009
                                </td>
                        </tr>
                        <tr>
                                <td>9. Platz</td>
                                <td>
                                        Landesmeisterschaft im Fahnenhochwurf Damen 2010
                                </td>
                        </tr>
                        <tr>
                                <td>7. Platz</td>
                                <td>
                                        Damen offene Klasse Deutsche Meisterschaft 2010
                                </td>
                        </tr>
                        <tr>
                                <td>7. Platz</td>
                                <td>
                                        Landesmeisterschaft im Fahnenhochwurf Damen 2011
                                </td>
                        </tr>
                        <tr>
                                <td>6. Platz</td>
                                <td>
                                        Damen offene Klasse Deutsche Meisterschaft 2012
                                </td>
                        </tr>
                        <tr>
                                <td>15. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf Damen 2012
                                </td>
                        </tr>
                        <tr>
                                <td>10. Platz</td>
                                <td>
                                        Einzel Damen offene Klasse Landesmeisterschaft 2013
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3  >Tatjana Ohnmacht</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>15. Platz</td>
                                <td>
                                        Damen B1 Landesmeisterschaft 2007
                                </td>
                        </tr>
                        <tr>
                                <td>6. Platz</td>
                                <td>
                                        Damen offene Klasse Landesmeisterschaft 2009
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Damen offene Klasse Landesmeisterschaft 2011
                                </td>
                        </tr>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        Landesmeisterschaft im Fahnenhochwurf Damen 2010
                                </td>
                        </tr>
                        <tr>
                                <td>9. Platz</td>
                                <td>
                                        Damen offene Klasse Deutsche Meisterschaft 2010
                                </td>
                        </tr>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        Landesmeisterschaft im Fahnenhochwurf Damen 2011
                                </td>
                        </tr>
                        <tr>
                                <td>15. Platz</td>
                                <td>
                                        Landesmeisterschaft im Fahnenhochwurf Damen 2012
                                </td>
                        </tr>
                        <tr>
                                <td>13. Platz</td>
                                <td>
                                        Damen offene Klasse Deutsche Meisterschaft 2012
                                </td>
                        </tr>
                        <tr>
                                <td>5. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf Damen 2012
                                </td>
                        </tr>
                        <tr>
                                <td>- Landesmeister -</td>
                                <td>
                                        2013 Einzel Damen offene Klasse
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3  >Jessica Vogt</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        Landesmeisterschaft im Fahnenhochwurf Mädchen AK4 2010
                                </td>
                        </tr>
                        <tr>
                                <td>9. Platz</td>
                                <td>
                                        Mädchen Deutsche Meisterschaft 2010
                                </td>
                        </tr>
                        <tr>
                                <td>5. Platz</td>
                                <td>
                                        Landesmeisterschaft im Fahnenhochwurf Damen 2011
                                </td>
                        </tr>
                        <tr>
                                <td>13. Platz</td>
                                <td>
                                        Einzel Damen offene Klasse Landesmeisterschaft 2013
                                </td>
                        </tr>
                        <tr>
                                <td>- Weltmeisterin -</td>
                                <td>
                                        im Fahnenhochwurf 2014 (8,0 m) in Rust
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2015 (Bruchsal)
                                </td>
                        </tr>
                        <tr>
                                <td>5. Platz</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2016 (Bad Mergentheim) Altersklasse Damen (7,00 m)
                                </td>
                        </tr>
                        <tr>
                                <td>12. Platz</td>
                                <td>
                                        Deutsche Meisterschaft 2017 (Bad Urach)
                                </td>
                        </tr>
                        <tr>
                                <td>9. Platz</td>
                                <td>
                                        17. Weltmeisterschaft im Fahnenhochwerfen in Nusplingen (2018) Klasse Damen offene Klasse (1979 – 2002) 7,500 m
                                </td>
                        </tr>
                        <tr>
                                <td>8. Platz</td>
                                <td>
                                        18. Weltmeisterschaft im Fahnenhochwerfen in Eschweiler (2019) Klasse Damen offene Klasse  (1980 – 2003) 6,000 m
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3  >Eric Gruner</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>7. Platz</td>
                                <td>
                                        Landesmeisterschaft im Fahnenhochwurf Jungen AK3 2012
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3  >Sitara Geisse</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        1. offene Süddeutsche-Meisterschaft Baden-Württemberg im Fahnenhochwerfen / Bretten
                                        <br>
                                        Altersklasse II (4,40 m)
                                </td>
                        </tr>
                        <tr>
                                <td>- Weltmeisterin -</td>
                                <td>
                                        17. Weltmeisterschaft im Fahnenhochwerfen in Nusplingen (2018) Klasse Mädchen AK III  (2005 – 2006) Höhe 7,000 m
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3  >Gruppen - Synchron</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>9. Platz</td>
                                <td>
                                        Landesmeisterschaft 2003 (Ute / Klaus / Monika)
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>Landesmeisterschaft 2005</td>
                        </tr>
                        <tr>
                                <td>8. Platz</td>
                                <td>
                                        Deutsche Meisterschaft 2006 (Ute / Klaus / Monika)
                                </td>
                        </tr>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        Jugend- Landesmeisterschaft 2007 (Julia / Melissa / Lorena)
                                </td>
                        </tr>
                        <tr>
                                <td>10. Platz</td>
                                <td>
                                        Landesmeisterschaft 2007 (Ute  / Klaus / Monika)
                                </td>
                        </tr>
                        <tr>
                                <td>8. Platz</td>
                                <td>Landesmeisterschaft 2009</td>
                        </tr>
                        <tr>
                                <td>6. Platz</td>
                                <td>
                                        Deutsche Meisterschaft 2010 (Julia / Melissa / Tatjana / Ute)
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Landesmeisterschaft 2011 (Melissa /  Tatjana / Ute)
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Deutsche Meisterschaft 2012 (Melissa / Tatjana / Ute / Lorena / Jessica)
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>Landesmeisterschaft 2013</td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3  >Duett</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        Landesmeisterschaft 2009 (Tatjana / Ute)
                                </td>
                        </tr>
                        <tr>
                                <td>5. Platz</td>
                                <td>
                                        Deutsche Meisterschaft 2010 (Julia / Melissa)
                                </td>
                        </tr>
                        <tr>
                                <td>7. Platz</td>
                                <td>
                                        Deutsche Meisterschaft 2010 (Tatjana / Ute)
                                </td>
                        </tr>
                        <tr>
                                <td>8. Platz</td>
                                <td>
                                        Landesmeisterschaft 2011 (Tatjana / Ute)
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        Deutsche Meisterschaft 2012 (Tatjana / Ute)
                                </td>
                        </tr>
                        <tr>
                                <td>8. Platz</td>
                                <td>
                                        Deutsche Meisterschaft 2012 (Lorena / Jessica)
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Landesmeisterschaft 2013 (Lorena / Melissa)
                                </td>
                        </tr>
                        <tr>
                                <td>7. Platz</td>
                                <td>
                                        Landesmeisterschaft 2013 (Ute / Monika)
                                </td>
                        </tr>
                        <tr>
                                <td>8. Platz</td>
                                <td>
                                        Deutsche Meisterschaft 2017 (Bad Urach) (Ute / Monika)
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3  >Show - Schwingen</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        Landesmeisterschaft 2011 (Lorena/ Melissa)
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        Landesmeisterschaft 2011 (Tatjana/ Ute)
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>
                                        Deutsche Meisterschaft 2012 (Jessica/Lorena/Melissa/Tatjana/Ute)
                                </td>
                        </tr>
                        <tr>
                                <td>5. Platz</td>
                                <td>
                                        Landesmeisterschaft 2013 (Jessica/Lorena/Melissa/Tatjana/Ute/Monika)
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
        <p>
                <a href="/fahnenschwingen/platzierungen#top">Nach oben</a>
        </p>
</div>
<div>
        <header>
                <h3  >Mannschaftswertung</h3>
        </header>
        <table>
                <tbody>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        Mannschaft- Jugend Landesmeisterschaft 2001
                                </td>
                        </tr>
                        <tr>
                                <td></td>
                                <td>
                                        WKG FS der Niederburg/ FZ Rottweil (Lorena)
                                </td>
                        </tr>
                        <tr>
                                <td>- Landesmeister -</td>
                                <td>
                                        2003 in der Mannschaft Rottweil Konstanz (Georg)
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>
                                        Weltmeister Fahnenhochwurf 2006  WKG Konstanz/Rottweil (Ute/Monika)
                                </td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>Deutsche Meisterschaft 2010</td>
                        </tr>
                        <tr>
                                <td>4. Platz</td>
                                <td>Deutsche Meisterschaft 2012</td>
                        </tr>
                        <tr>
                                <td>- Weltmeister -</td>
                                <td>
                                        Fahnenhochwurf 2012  WKG Konstanz/ Rottweil (Jessica) mit neuem Weltrekord 26,50 m
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        1. offene Süddeutsche-Meisterschaft Baden-Württemberg im Fahnenhochwerfen / Bretten
                                        <br>
                                        Damen Wettkampfgemeinschaft Rottweil / Rastatt (Lorena und Monika) (14,00 m)
                                </td>
                        </tr>
                        <tr>
                                <td>- Weltmeister -</td>
                                <td>
                                        Weltmeisterschaft im Fahnenhochwurf 2016 (Bad Mergentheim)
                                        <br>
                                        (Lorena, Jessica, Monika) Altersklasse Damen (15,00 m)
                                </td>
                        </tr>
                        <tr>
                                <td>3. Platz</td>
                                <td>
                                        17. Weltmeisterschaft im Fahnenhochwerfen in Nusplingen - Mannschaft Damen - 22,000 m
                                </td>
                        </tr>
                        <tr>
                                <td>2. Platz</td>
                                <td>
                                        18. Weltmeisterschaft im Fahnenhochwerfen in Eschweiler (2019) - Mannschaft Damen - 13,500 m
                                </td>
                        </tr>
                        <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                        </tr>
                </tbody>
        </table>
</div>