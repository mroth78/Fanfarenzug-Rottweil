<h2>Links</h2>

<h4>Fanfarenzüge</h4>
    <ul>
        <li><a href="http://www.spielleutemusik.com/" target="_blank" data-htmlarea-external="1" rel="noreferrer">Landesverband der Spielmanns- und Fanfarenzüge Baden-Württemberg</a></li> 
    </ul>

<h4>Fahnenschwinger</h4>
    <ul>
        <li><a href="http://www.fahnenschwinger-lfbw.de/" title="Opens external link in new window" target="_blank" class="external-link-new-window" data-htmlarea-external="1" rel="noreferrer">Landesverband der Fahnenschwinger Baden-Württemberg</a></li> 	
        <li><a href="http://www.fahnenschwinger.de/" title="Opens external link in new window" target="_blank" class="external-link-new-window" data-htmlarea-external="1" rel="noreferrer">Deutscher Fahnenschwingerverband</a></li> 
    </ul>

<h4>Allgemein</h4>
    <ul>
        <li><a href="http://www.rottweil.de/de" title="Opens external link in new window" target="_blank" class="external-link-new-window" rel="noreferrer">Stadt Rottweil (älteste Stadt Baden-Württemberg´s)</a> </li> 
    </ul>

<h4>Freunde</h4>
    <ul>
        <li><a href="http://rraetzcliquebrugg.npage.ch/index.html" title="Opens external link in new window" target="_blank" class="external-link-new-window" rel="noreferrer">Rrätz-Clique Brugg in der Schweiz</a></li>
        <li><a href="http://www.neckar-fleckle.de" title="Opens external link in new window" target="_blank" class="external-link-new-window" rel="noreferrer">Neckar-Fleckle Schwenningen e.V.</a></li>
    </ul>

