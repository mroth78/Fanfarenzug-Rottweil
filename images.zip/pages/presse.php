<h1>Presse</h1>

<h4>Ansprechpartner</h4>
<p>
    Fanfarenzug Rottweil 1978 e.V.<br> 
    Hochwaldstraße 41<br> 
    78628 Rottweil
</p>

<p>
    <a href="#" title="E-Mail an den Pressewart" class="mail" data-mailto-token="ocknvq,rtguugyctvBhcphctgpbwi/tqvvygkn0fg" data-mailto-vector="2">Pressewart</a>
</p>

<h4>Presseberichte 2018</h4>
<div class="row">
    <div class="col-1">
        <a href="/assets/presse/2018/20180321_Presseauswertung_NRWZ.pdf" target="_blank">
            <image src="/assets/presse/2018/20180321_Presseauswertung_NRWZ_Seite_1.jpg" width="150" height="195">
        </a>
    </div>

    <div class="col-1">
        <a href="/assets/presse/2018/20180322_Presseauswertung_schwabo.pdf" target="_blank">
            <image src="/assets/presse/2018/20180321_Presseauswertung_SCHWABO_Seite_1.jpg" width="150" height="195">
        </a>
    </div>

    <div class="col-1">
        <a href="/assets/presse/2018/20180322_Presseauswertung_schwabo.pdf" target="_blank">
            <image src="/assets/presse/2018/20180322_Presseauswertung_schwabo.jpg" width="150" height="195">
        </a>
    </div>
</div>

<h4>Presseberichte 2017</h4>
<div class="row">
    <div class="col-1">
        <a href="/assets/presse/2017/20170515_Presseauswertung_NRWZ.pdf" target="_blank">
            <image src="/assets/presse/2017/20170515_Presseauswertung_NRWZ_Seite_1.jpg" width="150" height="195">
        </a>
    </div>

    <div class="col-1">
        <a href="/assets/presse/2017/20170929_Presseauswertung_SCHWABO.pdf.pdf" target="_blank">
            <image src="/assets/presse/2017/20170929_Presseauswertung_SCHWABO_Seite_1.jpg" width="150" height="195">
        </a>
    </div>    
</div>