<h3 class="text-center">Herzlich Willkommen auf der Homepage des Fanfarenzug Rottweil 1978 e.V.</h3>

<img src="..\images\gruppenbild.jpg" class="img-fluid mx-auto d-block">