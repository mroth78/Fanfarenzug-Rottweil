<h2>Vorstand</h2>

<div class="container-fluid">
    <div class="row">
        <div class="col col-lg-2 col-md-3 col-xs-1">                        

            <figure class="figure">
                <img src="/images/pic_default.jpg" class="figure-img mx-auto d-block">
                <a href="#" class="mail" title="E-Mail an den 1. Vorstand">
                    <figcaption class="figure-caption text-center">Max Mustermann</figcaption>
                </a>
            </figure>
        </div>

        <div class="col col-lg-2 col-md-3 col-xs-1">                        
            <figure class="figure">
                <img src="/images/pic_default.jpg" class="figure-img mx-auto d-block">
                <a href="#" class="mail" title="E-Mail an den 2. Vorstand">
                    <figcaption class="figure-caption text-center">Max Mustermann</figcaption>
                </a>
            </figure>
        </div>

        <div class="col col-lg-2 col-md-3 col-xs-1">                        
            <figure class="figure">
                <img src="/images/pic_default.jpg" class="figure-img mx-auto d-block">
                <a href="#" class="mail" title="E-Mail an den Kassierer">
                    <figcaption class="figure-caption text-center">Max Mustermann</figcaption>
                </a>
            </figure>
        </div>

        <div class="col col-lg-2 col-md-3 col-xs-1">                        
            <figure class="figure">
                <img src="/images/pic_default.jpg" class="figure-img mx-auto d-block">
                <a href="#" class="mail" title="E-Mail an den Schriftführer">
                    <figcaption class="figure-caption text-center">Max Mustermann</figcaption>
                </a>
            </figure>
        </div>
    </div>
</div>
